const client_manifest = {
  "_Betrieb_Uttenreuth.cb8f17f4.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "Betrieb_Uttenreuth.5578e791.jpg"
    ],
    "file": "Betrieb_Uttenreuth.cb8f17f4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Betrieb_Uttenreuth.5578e791.jpg": {
    "file": "Betrieb_Uttenreuth.5578e791.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "__plugin-vue_export-helper.c27b6911.js": {
    "resourceType": "script",
    "module": true,
    "file": "_plugin-vue_export-helper.c27b6911.js"
  },
  "_filetable.f21a9c17.js": {
    "resourceType": "script",
    "module": true,
    "file": "filetable.f21a9c17.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ]
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.95c28eb4.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.fd576888.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.95c28eb4.css": {
    "file": "error-404.95c28eb4.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.e798523c.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.2274406f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.e798523c.css": {
    "file": "error-500.e798523c.css",
    "resourceType": "style"
  },
  "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.css": {
    "resourceType": "style",
    "file": "nuxt-icon.4544dae2.css",
    "src": "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.css"
  },
  "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "nuxt-icon.6d164bd1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icons/dist/runtime/components/nuxt-icon.vue"
  },
  "nuxt-icon.4544dae2.css": {
    "file": "nuxt-icon.4544dae2.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.3e44a8eb.css",
    "src": "pages/tem.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "css": [
      "entry.3e44a8eb.css"
    ],
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.d9902181.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.3e44a8eb.css": {
    "file": "entry.3e44a8eb.css",
    "resourceType": "style"
  },
  "pages/Annahme2.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "Annahme2.f48c9a85.png",
    "src": "pages/Annahme2.png"
  },
  "pages/Betrieb_Höchstadt.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "Betrieb_Höchstadt.18600569.jpg",
    "src": "pages/Betrieb_Höchstadt.jpg"
  },
  "pages/Betrieb_Uttenreuth.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "Betrieb_Uttenreuth.5578e791.jpg",
    "src": "pages/Betrieb_Uttenreuth.jpg"
  },
  "pages/DL.css": {
    "resourceType": "style",
    "file": "DL.0fba67f5.css",
    "src": "pages/DL.css"
  },
  "pages/DL.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "DL.40e991b3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "pages/Nav.vue",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/DL.vue"
  },
  "DL.0fba67f5.css": {
    "file": "DL.0fba67f5.css",
    "resourceType": "style"
  },
  "pages/Hös-start.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Hös-start.4ad21551.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Hös-start.vue"
  },
  "pages/Laden4.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "Laden4.44a7e501.jpg",
    "src": "pages/Laden4.jpg"
  },
  "pages/Nav.vue": {
    "resourceType": "script",
    "module": true,
    "file": "Nav.8215d9d5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Nav.vue"
  },
  "pages/Utt-start.css": {
    "resourceType": "style",
    "file": "Utt-start.714feee4.css",
    "src": "pages/Utt-start.css"
  },
  "pages/Utt-start.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "tanke-resize.49d479bc.jpg",
      "Laden4.44a7e501.jpg",
      "Annahme2.f48c9a85.png"
    ],
    "css": [],
    "file": "Utt-start.a410e704.js",
    "imports": [
      "_Betrieb_Uttenreuth.cb8f17f4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "pages/Nav.vue",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Utt-start.vue"
  },
  "Utt-start.714feee4.css": {
    "file": "Utt-start.714feee4.css",
    "resourceType": "style"
  },
  "tanke-resize.49d479bc.jpg": {
    "file": "tanke-resize.49d479bc.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "Laden4.44a7e501.jpg": {
    "file": "Laden4.44a7e501.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "Annahme2.f48c9a85.png": {
    "file": "Annahme2.f48c9a85.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/admin.css": {
    "resourceType": "style",
    "file": "admin.7e259916.css",
    "src": "pages/admin.css"
  },
  "pages/admin.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "admin.de022d6a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin.vue"
  },
  "admin.7e259916.css": {
    "file": "admin.7e259916.css",
    "resourceType": "style"
  },
  "pages/index.css": {
    "resourceType": "style",
    "file": "index.5b44a0f9.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "Betrieb_Höchstadt.18600569.jpg"
    ],
    "css": [],
    "file": "index.33ff38b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_Betrieb_Uttenreuth.cb8f17f4.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.5b44a0f9.css": {
    "file": "index.5b44a0f9.css",
    "resourceType": "style"
  },
  "Betrieb_Höchstadt.18600569.jpg": {
    "file": "Betrieb_Höchstadt.18600569.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/login.css": {
    "resourceType": "style",
    "file": "login.8dd89ec8.css",
    "src": "pages/login.css"
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "login.a85d721c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/login.vue"
  },
  "login.8dd89ec8.css": {
    "file": "login.8dd89ec8.css",
    "resourceType": "style"
  },
  "pages/mtt.vue": {
    "resourceType": "script",
    "module": true,
    "file": "mtt.d5cd9d09.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/mtt.vue"
  },
  "pages/tanke-resize.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "tanke-resize.49d479bc.jpg",
    "src": "pages/tanke-resize.jpg"
  },
  "pages/tem.css": {
    "resourceType": "style",
    "file": "entry.3e44a8eb.css",
    "src": "pages/tem.css"
  },
  "pages/tem.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "tem.844b6273.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/tem.vue"
  },
  "pages/twst.vue": {
    "resourceType": "script",
    "module": true,
    "file": "twst.442dd7a1.js",
    "imports": [
      "_filetable.f21a9c17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/twst.vue"
  },
  "pages/workers.vue": {
    "resourceType": "script",
    "module": true,
    "file": "workers.f9e51195.js",
    "imports": [
      "_filetable.f21a9c17.js",
      "node_modules/nuxt/dist/app/entry.js",
      "__plugin-vue_export-helper.c27b6911.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/workers.vue"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
