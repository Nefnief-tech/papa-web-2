const login_vue_vue_type_style_index_0_lang = ".pcenter{margin:auto}form{align-items:center;display:flex;flex-direction:column}";

const loginStyles_0a5462de = [login_vue_vue_type_style_index_0_lang, login_vue_vue_type_style_index_0_lang];

export { loginStyles_0a5462de as default };
//# sourceMappingURL=login-styles.0a5462de.mjs.map
