const DL_vue_vue_type_style_index_0_lang = ".card,.cards{display:flex;justify-content:center}.card{text-align:center}.carrd,.griiiddd{display:flex;justify-content:center}";

const DLStyles_d9263b1a = [DL_vue_vue_type_style_index_0_lang, DL_vue_vue_type_style_index_0_lang];

export { DLStyles_d9263b1a as default };
//# sourceMappingURL=DL-styles.d9263b1a.mjs.map
