const tem_vue_vue_type_style_index_0_lang = ".center{display:flex;justify-content:center}";

const temStyles_0f0d20e0 = [tem_vue_vue_type_style_index_0_lang, tem_vue_vue_type_style_index_0_lang];

export { temStyles_0f0d20e0 as default };
//# sourceMappingURL=tem-styles.0f0d20e0.mjs.map
