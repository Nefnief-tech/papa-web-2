const UttStart_vue_vue_type_style_index_0_lang = "img{border-radius:2rem}.center{text-align:center}.center,.grid,.img{display:flex;justify-content:center}";

const UttStartStyles_9749b92d = [UttStart_vue_vue_type_style_index_0_lang, UttStart_vue_vue_type_style_index_0_lang];

export { UttStartStyles_9749b92d as default };
//# sourceMappingURL=Utt-start-styles.9749b92d.mjs.map
