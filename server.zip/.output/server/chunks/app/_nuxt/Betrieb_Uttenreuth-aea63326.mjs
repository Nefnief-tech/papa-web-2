import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + buildAssetsURL("Betrieb_Uttenreuth.5578e791.jpg");

export { _imports_0 as _ };
//# sourceMappingURL=Betrieb_Uttenreuth-aea63326.mjs.map
