const index_vue_vue_type_style_index_0_lang = ".card-body{display:flex;justify-content:center}.center{text-align:center}.grid-parent{display:flex;justify-content:center}";

const indexStyles_c56e3505 = [index_vue_vue_type_style_index_0_lang, index_vue_vue_type_style_index_0_lang];

export { indexStyles_c56e3505 as default };
//# sourceMappingURL=index-styles.c56e3505.mjs.map
