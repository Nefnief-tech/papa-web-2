const admin_vue_vue_type_style_index_0_lang = ".center{display:flex;justify-content:center}body{height:100vh}.nav{bottom:3rem;position:fixed;width:100%}";

const adminStyles_4adfa962 = [admin_vue_vue_type_style_index_0_lang, admin_vue_vue_type_style_index_0_lang];

export { adminStyles_4adfa962 as default };
//# sourceMappingURL=admin-styles.4adfa962.mjs.map
