const nuxtIcon_vue_vue_type_style_index_0_lang = ".nuxt-icon svg{height:1em;margin-bottom:.125em;vertical-align:middle;width:1em}.nuxt-icon.nuxt-icon--fill,.nuxt-icon.nuxt-icon--fill *{fill:currentColor!important}.nuxt-icon.nuxt-icon--stroke,.nuxt-icon.nuxt-icon--stroke *{stroke:currentColor!important}";

const nuxtIconStyles_824ad423 = [nuxtIcon_vue_vue_type_style_index_0_lang, nuxtIcon_vue_vue_type_style_index_0_lang];

export { nuxtIconStyles_824ad423 as default };
//# sourceMappingURL=nuxt-icon-styles.824ad423.mjs.map
