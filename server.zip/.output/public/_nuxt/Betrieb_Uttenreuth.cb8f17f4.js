import"./entry.d9902181.js";const e=""+new URL("Betrieb_Uttenreuth.5578e791.jpg",import.meta.url).href;export{e as _};
