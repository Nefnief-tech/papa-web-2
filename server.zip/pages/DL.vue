<script setup>
import Nav from "./Nav.vue";
</script>

<template>
  <Usercounter />
  <Nav />

  <div class="center">
    <h1 class="text-center lg:text-5xl lg:font-black text-xl font-bold mt-10">
      Dienstleistungen
    </h1>
  </div>

  <div class="griiiddd mt-20">
    <div class="grid lg:grid-cols-3 lg:gap-10">
      <!-- cards -->
      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Inspektion/Service</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card-2 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Unfallinstandsetzung</h2>
          <p>
            Die Reparatur eines beschädigten Fahrzeugs ist ein komplexer
            Prozess, der von vielen Faktoren abhängt, wie z. B. der Schwere des
            Schadens, dem Alter des Fahrzeugs und den verfügbaren Ersatzteilen.
            Es ist wichtig, einen qualifizierten Mechaniker zu beauftragen, die
            Reparatur durchzuführen, um sicherzustellen, dass das Fahrzeug
            sicher und effizient ist.
          </p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card-3 -->
      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Reifen-service</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 4 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Mechanik</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 5 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Klime-service</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>
      <!-- card 6 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Autoglas-Service</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 7 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title text-center">Standheizung</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 8 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Elektrik/Elektronik</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 9 -->

      <div class="card w-96 bg-base-200 shadow-xl">
        <div class="card-body">
          <h2 class="card-title">Achsvermessung</h2>
          <p>If a dog chews shoes whose shoes does he choose?</p>
          <div class="card-actions justify-end"></div>
        </div>
      </div>

      <!-- card 10 -->

      <!-- end of cards --for now -->
    </div>
  </div>
</template>
<style>
.cards {
  display: flex;
  justify-content: center;
}
.card {
  display: flex;
  justify-content: center;
  text-align: center;
}
.carrd {
  display: flex;
  justify-content: center;
}
.griiiddd {
  display: flex;
  justify-content: center;
}
</style>
