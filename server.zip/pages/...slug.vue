<template>
  <title>404 not Found</title>

  <!-- 404 -->

  <div class="flex flex-col items-center justify-center h-screen">
    <h1 class="text-6xl font-bold">404</h1>
    <h2 class="text-2xl font-bold">Page not found</h2>
    <p class="text-xl">The page you are looking for does not exist.</p>
    <router-link to="/" class="btn btn-primary mt-4">Go back home</router-link>
  </div>
</template>
