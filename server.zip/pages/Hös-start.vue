<script>
import Nav from "./Nav.vue";
</script>

<template>
  <Usercounter />
  <Nav />
</template>
