<!-- app.vue -->

<template>
  <cookiebanner />
  <NuxtPage />
  <Usercounter />
</template>

<script setup lang="ts">
import Nav from "./pages/Nav.vue";
</script>
